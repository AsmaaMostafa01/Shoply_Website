import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';

import '../App.css';
import Breadcrumb from '../components/Breadcrumb';

const SignUp = () => {
  return (
    <div>
      <Header />
      <Breadcrumb page="Sign Up " />
      <main> 
        <section className="content">
                <img src="/sign up.jpg" alt="Shopping"/>
                <div className="form-container">
                    <h2>Create an account</h2>
                    <p>Enter your details below</p>
                    <form>
                        <input type="text" placeholder="Name" required />
                        <input type="email" placeholder="Email or Phone Number" required />
                        <input type="password" placeholder="Password" required />
                        <button type="submit">Create Account</button>
                        <button className="google-signup"><img src="/google.png" alt="Google Icon" /> 
                            Sign up with Google</button>
                 
                    </form>
                    
                    <div className="login-link">
                        <span>Already have an account? <a href="#">Log In</a></span>
                    </div>
                </div>
            </section>
      </main>
      <Footer />
    </div>
  );
}

export default SignUp;
